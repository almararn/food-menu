import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'models/meal.dart';
import 'services/api_service.dart';

void main() => runApp(const TDKFoodApp());

class TDKFoodApp extends StatefulWidget {
  const TDKFoodApp({super.key});

  @override
  State<TDKFoodApp> createState() => _TDKFoodAppState();
}

class _TDKFoodAppState extends State<TDKFoodApp> {
  bool isIcelandic = true;
  List<Meal>? cachedMeals;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadMenu();
  }

  Future<void> _loadMenu() async {
    // Ensure this returns Future<void>
    setState(() => isLoading = true);
    try {
      final meals = await ApiService.fetchMenu();
      setState(() {
        cachedMeals = List.from(meals);
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true),
      home: HomeScreen(
        // Keep the Key to help Flutter track the state change
        key: ValueKey(cachedMeals?.hashCode ?? 0),
        isIcelandic: isIcelandic,
        onToggleLanguage: () => setState(() => isIcelandic = !isIcelandic),
        meals: cachedMeals,
        isLoading: isLoading,
        // This is the important part: we pass the function directly
        onRefresh: _loadMenu,
      ),
    );
  }
}
