import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // Add this
import 'package:firebase_auth/firebase_auth.dart'; // Add this
import 'firebase_options.dart'; // Add this
import 'screens/home_screen.dart';
import 'screens/login_screen.dart'; // Add this
import 'services/auth_service.dart'; // Add this
import 'models/meal.dart';
import 'services/api_service.dart';

// Update main to be async for Firebase
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const TDKFoodApp());
}

class TDKFoodApp extends StatefulWidget {
  const TDKFoodApp({super.key});

  @override
  State<TDKFoodApp> createState() => _TDKFoodAppState();
}

class _TDKFoodAppState extends State<TDKFoodApp> {
  bool isIcelandic = true;
  final ValueNotifier<List<Meal>> menuNotifier = ValueNotifier<List<Meal>>([]);
  final ValueNotifier<List<String>> orderedDatesNotifier =
      ValueNotifier<List<String>>([]);
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
  }

  Future<void> _loadInitialData() async {
    if (!mounted) return;
    setState(() => isLoading = true);

    try {
      // Both requests fire at the same time
      final results = await Future.wait([
        ApiService.fetchMenu(),
        ApiService.fetchOrderedDates(),
      ]);

      menuNotifier.value = results[0] as List<Meal>;
      orderedDatesNotifier.value = results[1] as List<String>;
    } catch (e) {
      debugPrint("Startup Error: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true),
      home: StreamBuilder<User?>(
        stream: AuthService().user,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.hasData) {
            _loadInitialData;
            if (menuNotifier.value.isEmpty && !isLoading) {
              // Use microtask to avoid calling setState during build
              Future.microtask(() => _loadInitialData());
            }

            return HomeScreen(
              isIcelandic: isIcelandic,
              onToggleLanguage: () =>
                  setState(() => isIcelandic = !isIcelandic),
              menuNotifier: menuNotifier,
              orderedDatesNotifier: orderedDatesNotifier,
              isLoading: isLoading,
              onRefresh: _loadInitialData,
            );
          }
          return const LoginScreen();
        },
      ),
    );
  }
}
