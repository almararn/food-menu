import 'package:flutter/material.dart';
import 'day_selection_screen.dart';
import '../models/meal.dart';

class HomeScreen extends StatelessWidget {
  final bool isIcelandic;
  final VoidCallback onToggleLanguage;
  final List<Meal>? meals;
  final bool isLoading;
  final Future<void> Function() onRefresh; // Change from VoidCallback to this

  const HomeScreen({
    super.key,
    required this.isIcelandic,
    required this.onToggleLanguage,
    this.meals,
    required this.isLoading,
    required this.onRefresh, // Update here
  });

  @override
  Widget build(BuildContext context) {
    // Determine if the "Order Food" button should be active
    // It is active only if NOT loading AND meals have been fetched
    bool isMenuReady = !isLoading && meals != null && meals!.isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blueGrey.shade900,
        centerTitle: true,
        title: Text(
          isIcelandic ? 'TDK Iceland' : 'TDK Staff App',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: TextButton(
              onPressed: onToggleLanguage,
              style: TextButton.styleFrom(foregroundColor: Colors.orange),
              child: Text(
                isIcelandic ? "🇬🇧 ENG" : "🇮🇸 ISL",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildBigButton(
              context,
              title: isIcelandic ? "Panta Mat" : "Order Food",
              // - Show explanation if loading or empty
              subtitle: isLoading
                  ? (isIcelandic ? "Sæki matseðil..." : "Fetching menu...")
                  : (isMenuReady
                        ? (isIcelandic ? "Matseðill vikunnar" : "Weekly Menu")
                        : (isIcelandic
                              ? "Matseðill ekki klár"
                              : "Menu not ready")),
              icon: Icons.restaurant_menu_rounded,
              color: isMenuReady ? Colors.orange : Colors.grey.shade400, //
              onTap: isMenuReady
                  ? () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DaySelectionScreen(
                            isIcelandic: isIcelandic,
                            // Change this line to be a function
                            getMeals: () => meals,
                            onRefresh: onRefresh,
                          ),
                        ),
                      );
                    }
                  : () {},
            ),
            const SizedBox(height: 24),
            // --- VIEW ORDERS BUTTON ---
            _buildBigButton(
              context,
              title: isIcelandic ? "Mínar Pantanir" : "My Orders",
              subtitle: isIcelandic ? "Saga og yfirlit" : "History & Overview",
              icon: Icons.history_rounded,
              color: Colors.blueGrey.shade700,
              onTap: () {
                // Future History Screen
              },
            ),
          ],
        ),
      ),
    );
  }

  // Helper for the big buttons
  Widget _buildBigButton(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 140,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
        ),
        onPressed: onTap,
        child: Row(
          children: [
            Icon(icon, size: 40),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      ),
    );
  }
}
