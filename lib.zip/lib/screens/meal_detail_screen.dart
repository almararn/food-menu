import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../services/api_service.dart';

class MealDetailScreen extends StatefulWidget {
  final String date;
  final List<Meal> allMeals;
  final bool isIcelandic;
  final ValueNotifier<List<String>> orderedDatesNotifier;

  const MealDetailScreen({
    super.key,
    required this.date,
    required this.allMeals,
    required this.isIcelandic,
    required this.orderedDatesNotifier,
  });

  @override
  State<MealDetailScreen> createState() => _MealDetailScreenState();
}

class _MealDetailScreenState extends State<MealDetailScreen> {
  Timer? _timer;
  Duration _timeLeft = Duration.zero;
  bool _isPastDeadline = false;
  bool _isToday = false;

  // This tracks which specific meal name was ordered for this date
  String? _specificOrderedMealName;

  @override
  void initState() {
    super.initState();
    _calculateTime();
    _findOrderedMealName();
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) => _calculateTime(),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // Uses your ApiService to find exactly what was ordered for this day
  Future<void> _findOrderedMealName() async {
    final history = await ApiService.fetchOrderHistoryDetails();
    final normalizedScreenDate = widget.date.replaceAll('/', '.');

    for (var order in history) {
      String orderDate = order['mealDate'].toString().replaceAll('/', '.');
      // If your API returns ISO strings, we normalize those too
      if (orderDate.contains('T')) {
        orderDate = orderDate.split('T')[0].split('-').reversed.join('.');
      }

      if (orderDate == normalizedScreenDate) {
        if (mounted) {
          setState(() {
            _specificOrderedMealName =
                order['meal']; // 'meal' matches your placeOrder key
          });
        }
        break;
      }
    }
  }

  void _calculateTime() {
    final now = DateTime.now();
    try {
      String cleanDate = widget.date.replaceAll('/', '.');
      List<String> parts = cleanDate.split('.');
      DateTime mealDate = DateTime(
        int.parse(parts[2]),
        int.parse(parts[1]),
        int.parse(parts[0]),
      );
      DateTime deadline = DateTime(
        mealDate.year,
        mealDate.month,
        mealDate.day,
        10,
        0,
      );

      if (mounted) {
        setState(() {
          _isToday =
              now.year == mealDate.year &&
              now.month == mealDate.month &&
              now.day == mealDate.day;
          _isPastDeadline = now.isAfter(deadline);
          _timeLeft = deadline.difference(now);
        });
      }
    } catch (_) {}
  }

  Future<void> _handleCancel() async {
    _showLoadingDialog(context);
    // Passing the date exactly as your API expects
    bool success = await ApiService.cancelOrder(mealDate: widget.date);
    if (mounted) Navigator.pop(context);

    if (success) {
      setState(() => _specificOrderedMealName = null);
      List<String> newList = List<String>.from(
        widget.orderedDatesNotifier.value,
      );
      newList.remove(widget.date.replaceAll('/', '.'));
      widget.orderedDatesNotifier.value = newList;
      _showSnackBar(
        widget.isIcelandic ? "Pöntun eytt" : "Order Cancelled",
        Colors.orange,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final dailyMeals = widget.allMeals
        .where((m) => m.fullDate == widget.date)
        .toList();
    bool showCountdown =
        _isToday &&
        _timeLeft.inMinutes < 60 &&
        !_timeLeft.isNegative &&
        !_isPastDeadline;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.blueGrey.shade900,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          widget.isIcelandic ? "Matseðill" : "Menu",
          style: const TextStyle(color: Colors.white),
        ),
        actions: [if (showCountdown) _buildCountdownBadge()],
      ),
      body: ValueListenableBuilder<List<String>>(
        valueListenable: widget.orderedDatesNotifier,
        builder: (context, orderedDates, _) {
          // Normalize to match your fetchOrderedDates() logic
          final normalizedTarget = widget.date.replaceAll('/', '.');
          bool dayAlreadyOrdered = orderedDates.contains(normalizedTarget);

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: dailyMeals.length,
            itemBuilder: (context, index) {
              final meal = dailyMeals[index];
              final mealName = widget.isIcelandic
                  ? meal.mealNameIs
                  : meal.mealName;

              // Check if this specific card is the one ordered
              bool isThisTheOne = _specificOrderedMealName == mealName;

              return _buildMealCard(
                meal,
                mealName,
                widget.isIcelandic ? meal.descriptionIs : meal.descriptionEn,
                canOrder: !_isPastDeadline && !dayAlreadyOrdered,
                dayAlreadyOrdered: dayAlreadyOrdered,
                showCancel: isThisTheOne && !_isPastDeadline,
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildMealCard(
    Meal meal,
    String name,
    String desc, {
    required bool canOrder,
    required bool dayAlreadyOrdered,
    required bool showCancel,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            name,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const Divider(height: 30),
          Text(
            desc,
            style: const TextStyle(
              fontSize: 16,
              height: 1.5,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 30),

          if (showCancel)
            _buildCancelAction()
          else
            _buildOrderAction(meal, canOrder, dayAlreadyOrdered),
        ],
      ),
    );
  }

  Widget _buildOrderAction(Meal meal, bool canOrder, bool dayAlreadyOrdered) {
    String label = _isPastDeadline
        ? (widget.isIcelandic ? "LOKAÐ" : "CLOSED")
        : (dayAlreadyOrdered
              ? (widget.isIcelandic ? "ÞEGAR PANTAÐ" : "ALREADY ORDERED")
              : (widget.isIcelandic ? "PANTA NÚNA" : "ORDER NOW"));

    return SizedBox(
      width: double.infinity,
      height: 55,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: canOrder ? Colors.orange : Colors.grey.shade300,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        onPressed: canOrder ? () => _showOrderConfirmation(meal) : null,
        child: Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildCancelAction() {
    return SizedBox(
      width: double.infinity,
      height: 55,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Colors.red, width: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        onPressed: _handleCancel,
        child: Text(
          widget.isIcelandic ? "HÆTTA VIÐ PÖNTUN" : "CANCEL ORDER",
          style: const TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildCountdownBadge() {
    String timeStr =
        "${_timeLeft.inMinutes.toString().padLeft(2, '0')}:${(_timeLeft.inSeconds % 60).toString().padLeft(2, '0')}";
    return Center(
      child: Container(
        margin: const EdgeInsets.only(right: 16),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.redAccent.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          timeStr,
          style: const TextStyle(
            color: Colors.redAccent,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  void _showOrderConfirmation(Meal meal) {
    final user = FirebaseAuth.instance.currentUser;
    final nameController = TextEditingController(
      text: user?.displayName ?? user?.email?.split('@')[0] ?? "",
    );
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(widget.isIcelandic ? "Staðfesta" : "Confirm"),
        content: TextField(
          controller: nameController,
          decoration: InputDecoration(
            labelText: widget.isIcelandic ? "Nafn" : "Name",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              final mName = widget.isIcelandic
                  ? meal.mealNameIs
                  : meal.mealName;
              Navigator.pop(ctx);
              _showLoadingDialog(context);
              bool success = await ApiService.submitOrder(
                mealName: mName,
                manualName: nameController.text,
                mealDate: meal.date,
                mealDay: meal.day,
                description: widget.isIcelandic
                    ? meal.descriptionIs
                    : meal.descriptionEn,
              );
              if (mounted) Navigator.pop(context);
              if (success && mounted) {
                setState(() => _specificOrderedMealName = mName);
                widget.orderedDatesNotifier.value = List<String>.from(
                  widget.orderedDatesNotifier.value,
                )..add(widget.date.replaceAll('/', '.'));
              }
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  void _showLoadingDialog(BuildContext context) => showDialog(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => const Center(child: CircularProgressIndicator()),
  );
  void _showSnackBar(String msg, Color color) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
}
