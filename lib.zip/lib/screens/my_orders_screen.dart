import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';

class MyOrdersScreen extends StatelessWidget {
  final bool isIcelandic;

  const MyOrdersScreen({super.key, required this.isIcelandic});

  // 1. HELPER: Translate days to Icelandic
  String _translateDay(String day) {
    if (!isIcelandic) return day;
    final dayMap = {
      'Monday': 'Mánudagur',
      'Tuesday': 'Þriðjudagur',
      'Wednesday': 'Miðvikudagur',
      'Thursday': 'Fimmtudagur',
      'Friday': 'Föstudagur',
      'Saturday': 'Laugardagur',
      'Sunday': 'Sunnudagur',
    };
    return dayMap[day] ?? day;
  }

  // 2. HELPER: Format date to 09.01.2026
  String _formatMealDate(dynamic rawDate) {
    if (rawDate == null) return "";
    String dateStr = rawDate.toString();
    try {
      DateTime dt = dateStr.contains('T')
          ? DateTime.parse(dateStr)
          : DateFormat("dd/MM/yyyy").parse(dateStr);
      return DateFormat('dd.MM.yyyy').format(dt);
    } catch (e) {
      return dateStr.replaceAll('/', '.');
    }
  }

  // 3. HELPER: Sort Oldest First
  List<dynamic> _sortOrders(List<dynamic> orders) {
    orders.sort((a, b) {
      try {
        DateTime dateA = a['mealDate'].toString().contains('T')
            ? DateTime.parse(a['mealDate'])
            : DateFormat("dd/MM/yyyy").parse(a['mealDate']);
        DateTime dateB = b['mealDate'].toString().contains('T')
            ? DateTime.parse(b['mealDate'])
            : DateFormat("dd/MM/yyyy").parse(b['mealDate']);
        return dateA.compareTo(dateB); // dateA first = Oldest First
      } catch (e) {
        return 0;
      }
    });
    return orders;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey.shade900,
        title: Text(
          isIcelandic ? "Mínar pantanir" : "My Orders",
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.fetchOrderHistoryDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.orange),
            );
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text(
                isIcelandic ? "Engar pantanir fundust" : "No orders found",
              ),
            );
          }

          final orders = _sortOrders(List.from(snapshot.data!));

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              return Card(
                elevation: 0,
                color: Colors.grey.shade50,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: ListTile(
                  title: Text(
                    order['mealName'] ?? "",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    "${_translateDay(order['mealDay'] ?? "")} - ${_formatMealDate(order['mealDate'])}",
                  ),
                  trailing: const Icon(
                    Icons.history,
                    size: 16,
                    color: Colors.grey,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
