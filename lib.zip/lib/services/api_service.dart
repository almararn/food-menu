import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'dart:convert';
import '../models/meal.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ApiService {
  static const String _url =
      'https://script.google.com/macros/s/AKfycbxbdSWRScm6bVB4kl0ofoo_NFJDnwmZktXCBhJoaMAY_1Oi1GyS8lMjsYT9NJP8CRSP/exec';

  // 1. Fetch Menu
  static Future<List<Meal>> fetchMenu() async {
    try {
      final response = await http.get(Uri.parse('$_url?action=getMenu'));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => Meal.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // 2. Submit Order
  static Future<bool> submitOrder({
    required String mealName,
    required String manualName,
    required String mealDate,
    required String mealDay,
    required String description,
  }) async {
    final user = FirebaseAuth.instance.currentUser;

    // Shortening description for better Google Sheet readability
    String shortDesc = description.length > 25
        ? "${description.substring(0, 25)}..."
        : description;

    try {
      final response = await http.post(
        Uri.parse(_url),
        body: {
          "action": "placeOrder",
          "meal": mealName,
          "userName": manualName,
          "userEmail": user?.email ?? "No Email",
          "mealDate": mealDate,
          "mealDay": mealDay,
          "description": shortDesc,
          "orderedAt": DateTime.now().toLocal().toString(),
        },
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> cancelOrder({required String mealDate}) async {
    final user = FirebaseAuth.instance.currentUser;
    try {
      final response = await http.post(
        Uri.parse(_url),
        body: {
          "action": "cancelOrder",
          "userEmail": user?.email ?? "",
          "mealDate": mealDate,
        },
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 3. Fetch Ordered Dates (Normalized)
  static Future<List<String>> fetchOrderedDates() async {
    // Add a tiny delay or check to ensure Firebase has the user ready
    final user = FirebaseAuth.instance.currentUser;

    print("Fetching orders for: ${user?.email}");

    if (user == null) {
      // If user is null, wait 500ms and try one last time
      await Future.delayed(const Duration(milliseconds: 500));
    }

    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null || currentUser.email == null) return [];

    try {
      // Now we are sure we have an email
      final response = await http.get(
        Uri.parse('$_url?action=getUserOrders&email=${currentUser.email}'),
      );
      if (response.statusCode == 200) {
        List<dynamic> orders = json.decode(response.body);

        return orders.map((order) {
          String rawDate = order['mealDate'].toString();

          // Convert ISO timestamps (2026-01-06T...) to 06.01.2026
          if (rawDate.contains('T')) {
            try {
              return DateFormat('dd.MM.yyyy').format(DateTime.parse(rawDate));
            } catch (_) {}
          }
          // Convert 06/01/2026 to 06.01.2026
          return rawDate.replaceAll('/', '.');
        }).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // New method to fetch full order history details for MyOrdersScreen
  static Future<List<dynamic>> fetchOrderHistoryDetails() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email == null) return [];

    try {
      final response = await http.get(
        Uri.parse('$_url?action=getUserOrders&email=${user.email}'),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return [];
    } catch (e) {
      return [];
    }
  }
}
